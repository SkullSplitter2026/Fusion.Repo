import json
import socket
import re
from gzip import GzipFile

import requests
import urllib3

from urllib .parse import urlparse
import xbmc ,xbmcvfs

from .import userdata ,settings
from .util import get_kodi_proxy
from .dns import get_dns_rewrites
from .log import log
from .language import _
from .exceptions import SessionError
from .constants import DEFAULT_USERAGENT ,CHUNK_SIZE

urllib3 .disable_warnings (urllib3 .exceptions .InsecureRequestWarning )

DEFAULT_HEADERS ={
'User-Agent':DEFAULT_USERAGENT ,
}

def json_override (func ,error_msg ):
    try :
        return func ()
    except Exception as e :
        raise SessionError (error_msg or _ .JSON_ERROR )

orig_getaddrinfo =socket .getaddrinfo

class RawSession (requests .Session ):
    def __init__ (self ,verify =None ,timeout =None ):
        super (RawSession ,self ).__init__ ()
        self ._verify =verify
        self ._timeout =timeout
        self ._dns_cache ={}
        self ._session_cache ={}
        self ._rewrites =[]
        self ._proxy =None
        self ._cert =None

    def set_dns_rewrites (self ,rewrites ):
        for entries in rewrites :
            pattern =entries .pop ()
            pattern =re .escape (pattern ).replace ('\\*','.*')
            pattern =re .compile (pattern ,flags =re .IGNORECASE )

            new_entries =[]
            for entry in entries :
                _type ='skip'
                if entry .startswith ('>'):
                    _type ='proxy'
                    entry =entry [1 :]
                elif entry [0 ].isdigit ():
                    _type ='dns'
                else :
                    _type ='url_sub'
                new_entries .append ([_type ,entry ])

            self ._rewrites .append ([pattern ,sorted (new_entries ,key =lambda x :x [0 ]=='dns')])

    def set_cert (self ,cert ):
        self ._cert =cert
        log .debug ('Cert set to: {}'.format (cert ))

    def _get_cert (self ):
        if not self ._cert :
            return None
        pem ,key =self ._cert
        if pem .lower ().startswith ('http'):
            log .debug ('Downloading pem: {}'.format (pem ))
            resp =requests .get (pem )
            pem =xbmcvfs .translatePath ('special://temp/temp.pem')
            with open (pem ,'wb')as f :
                f .write (resp .content )
        if key .lower ().startswith ('http'):
            log .debug ('Downloading key: {}'.format (key ))
            resp =requests .get (key )
            key =xbmcvfs .translatePath ('special://temp/temp.key')
            with open (key ,'wb')as f :
                f .write (resp .content )
        self ._cert =(xbmcvfs .translatePath (pem ),xbmcvfs .translatePath (key ))
        return self ._cert

    def set_proxy (self ,proxy ):
        self ._proxy =proxy

    def _get_proxy (self ):
        if self ._proxy and self ._proxy .lower ().strip ()=='kodi':
            self ._proxy =get_kodi_proxy ()
        return self ._proxy

    def request (self ,method ,url ,**kwargs ):
        req =requests .Request (method ,url ,params =kwargs .pop ('params',None ))
        url =req .prepare ().url

        session_data ={
        'proxy':None ,
        'rewrite':None ,
        'url':url ,
        }

        if url in self ._session_cache :
            session_data =self ._session_cache [url ]
        elif self ._rewrites :
            for row in self ._rewrites :
                if not row [0 ].search (url ):
                    continue

                for entry in row [1 ]:
                    if entry [0 ]=='skip':
                        continue
                    if entry [0 ]=='url_sub':
                        session_data ['url']=re .sub (row [0 ],entry [1 ],url ,count =1 )
                    elif entry [0 ]=='proxy':
                        session_data ['proxy']=entry [1 ]
                    elif entry [0 ]=='dns':
                        session_data ['rewrite']=[urlparse (session_data ['url']).netloc .lower (),entry [1 ]]
                break

            self ._session_cache [url ]=session_data

        def connection_from_pool_key (self ,pool_key ,request_context =None ):

            if session_data ['rewrite'][0 ]==request_context ['host']:
                pool_key =pool_key ._replace (key_server_hostname =session_data ['rewrite'][1 ])
            return orig_connection_from_pool_key (self ,pool_key ,request_context )

        def getaddrinfo (host ,port ,family =0 ,_type =0 ,proto =0 ,flags =0 ):
            if session_data ['rewrite'][0 ]==host :
                log .debug ("DNS Rewrite: {} -> {}".format (host ,session_data ['rewrite'][1 ]))
                host =session_data ['rewrite'][1 ]

            if host in self ._dns_cache :
                return self ._dns_cache [host ]

            try :
                addresses =orig_getaddrinfo (host ,port ,socket .AF_INET ,_type ,proto ,flags )
            except socket .gaierror :
                addresses =orig_getaddrinfo (host ,port ,socket .AF_INET6 ,_type ,proto ,flags )

            self ._dns_cache [host ]=addresses
            return addresses

        if session_data ['url']!=url :
            log .debug ("URL Changed: {}".format (session_data ['url']))

        if session_data ['proxy']is None :
            session_data ['proxy']=self ._get_proxy ()

        if session_data ['proxy']:

            parsed =urlparse (session_data ['proxy'])
            replaced =parsed ._replace (netloc ="{}:{}@{}".format ('username','password',parsed .hostname )if parsed .username else parsed .hostname )
            log .debug ("Proxy: {}".format (replaced .geturl ()))

            kwargs ['proxies']={
            'http':session_data ['proxy'],
            'https':session_data ['proxy'],
            }

        if self ._cert :
            kwargs ['verify']=False
            kwargs ['cert']=self ._get_cert ()

        if 'verify'not in kwargs :
            kwargs ['verify']=self ._verify

        if 'timeout'not in kwargs :
            kwargs ['timeout']=self ._timeout

        orig_getaddrinfo =socket .getaddrinfo
        orig_connection_from_pool_key =urllib3 .PoolManager .connection_from_pool_key

        try :
            if session_data ['rewrite']:

                socket .getaddrinfo =getaddrinfo
                urllib3 .PoolManager .connection_from_pool_key =connection_from_pool_key

            result =super (RawSession ,self ).request (method ,session_data ['url'],**kwargs )
        finally :

            socket .getaddrinfo =orig_getaddrinfo
            urllib3 .PoolManager .connection_from_pool_key =orig_connection_from_pool_key

        return result

class Session (RawSession ):
    def __init__ (self ,headers =None ,cookies_key =None ,base_url ='{}',timeout =None ,attempts =None ,verify =None ,dns_rewrites =None ):
        super (Session ,self ).__init__ (verify =settings .common_settings .getBool ('verify_ssl',True )if verify is None else verify ,
        timeout =settings .common_settings .getInt ('http_timeout',30 )if timeout is None else timeout )

        self ._headers =headers or {}
        self ._cookies_key =cookies_key
        self ._base_url =base_url
        self ._attempts =settings .common_settings .getInt ('http_retries',2 )if attempts is None else attempts
        self .before_request =None
        self .after_request =None

        self .set_dns_rewrites (get_dns_rewrites ()if dns_rewrites is None else dns_rewrites )
        self .set_proxy (settings .get ('proxy_server')or settings .common_settings .get ('proxy_server'))

        self .headers .update (DEFAULT_HEADERS )
        self .headers .update (self ._headers )

        if self ._cookies_key :
            self .cookies .update (userdata .get (self ._cookies_key ,{}))

    def gz_json (self ,*args ,**kwargs ):
        resp =self .get (*args ,**kwargs )
        json_text =GzipFile (fileobj =BytesIO (resp .content )).read ()
        return json .loads (json_text )

    def request (self ,method ,url ,timeout =None ,attempts =None ,verify =None ,error_msg =None ,retry_not_ok =False ,retry_delay =1000 ,log_url =None ,**kwargs ):
        method =method .upper ()

        if not url .startswith ('http'):
            url =self ._base_url .format (url )

        attempts =self ._attempts if attempts is None else attempts

        if timeout is not None :
            kwargs ['timeout']=timeout

        if verify is not None :
            kwargs ['verify']=verify

        for i in range (1 ,attempts +1 ):
            attempt ='Attempt {}/{}: '.format (i ,attempts )
            if i >1 and retry_delay :
                xbmc .sleep (retry_delay )

            if self .before_request :
                self .before_request ()

            log ('{}{} {}'.format (attempt ,method ,log_url or url ))

            try :
                resp =super (Session ,self ).request (method ,url ,**kwargs )
            except :
                resp =None
                if i ==attempts :
                    raise
                else :
                    continue

            if resp is None :
                raise SessionError (error_msg or _ .NO_RESPONSE_ERROR )

            if retry_not_ok and not resp .ok :
                continue
            else :
                break

        resp .json =lambda func =resp .json ,error_msg =error_msg :json_override (func ,error_msg )

        if self .after_request :
            self .after_request (resp )

        return resp

    def save_cookies (self ):
        if not self ._cookies_key :
            raise Exception ('A cookies key needs to be set to save cookies')

        userdata .set (self ._cookies_key ,self .cookies .get_dict ())

    def clear_cookies (self ):
        if self ._cookies_key :
            userdata .delete (self ._cookies_key )
        self .cookies .clear ()

    def chunked_dl (self ,url ,dst_path ,method ='GET',**kwargs ):
        kwargs ['stream']=True
        resp =self .request (method ,url ,**kwargs )
        resp .raise_for_status ()

        with open (dst_path ,'wb')as f :
            for chunk in resp .iter_content (CHUNK_SIZE ):
                f .write (chunk )

        return resp
